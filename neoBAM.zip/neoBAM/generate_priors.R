generate_priors=function(parameters){
    
    
    source('/nas/cee-water/cjgleason/colin/Asia_neobam/prior_functions.R')
#library(stringr, lib.loc = "/nas/cee-water/cjgleason/r-lib/",quietly = TRUE,warn.conflicts=FALSE)
library(settings, lib.loc = "/nas/cee-water/cjgleason/r-lib/",quietly = TRUE,warn.conflicts=FALSE)
library(rslurm, lib.loc = "/nas/cee-water/cjgleason/r-lib/",quietly = TRUE,warn.conflicts=FALSE)
library(whisker, lib.loc = "/nas/cee-water/cjgleason/r-lib/",quietly = TRUE,warn.conflicts=FALSE)
#library(geoBAMr, lib.loc = "/nas/cee-water/cjgleason/r-lib/",quietly = TRUE,warn.conflicts=FALSE)


Wobs=parameters$Wobs
Sobs=parameters$Sobs
Q_priors=parameters$Q_priors
date=parameters$date
sample_size=parameters$sample_size
    

 
    
      index_of_nodata_row=rowSums(is.na(Wobs)) > (ncol(Wobs)-5)
      Wobs=Wobs[!index_of_nodata_row,]

    
    #this has presampled to throw out rows and columns without enough data
       if (is.null(nrow(Wobs)) || is.null(ncol(Wobs)) ) {return(list('geo_priors'=NA))}
       if (nrow(Wobs)<5 || ncol(Wobs) < 5 ) {return(list('geo_priors'=NA))}
    
      index_of_nodata_col=colSums(is.na(Wobs)) > (nrow(Wobs)-5)
      Wobs=Wobs[,!index_of_nodata_col]
      date=date[!index_of_nodata_col]
    


    #this has presampled to throw out rows and columns without enough data
      if (is.null(nrow(Wobs)) || is.null(ncol(Wobs)) ) {return(list('geo_priors'=NA))}
      if (nrow(Wobs)<5 || ncol(Wobs) < 5 ) {return(list('geo_priors'=NA))}
    
    #if there is enough to be subsampled, priveledge more dates rather than a 'tight' matrix
     
    
      if(nrow(Wobs)>parameters$sample_size){
          order_frame=data.frame(row=1:nrow(Wobs),nt=rowSums(!is.na(Wobs)))
          keep_index=order(order_frame$nt, decreasing=TRUE)[1:sample_size]
          Wobs=Wobs[keep_index,] 
      
      }    
    
    
      Q_priors$logQ_hat=rep(Q_priors$logQ_hat, times=ncol(Wobs))
      Q_priors$logQ_sd=rep(Q_priors$logQ_sd, times=ncol(Wobs))
  
      Sobsmat= matrix(Sobs,nrow=nrow(Wobs),ncol=ncol(Wobs))
      Sobs=Sobsmat     
      #organize geoBAM data
      Qmean=exp(parameters$Q_priors$logQ_hat)
    
    
      bamdata = bam_data(w=Wobs,Qhat=as.vector(Qmean),max_xs=40L,s=Sobs, variant = "amhg") 
  
 
  #make full BAM priors (increase knowledge content as much as possible)
  makeBamPriors = function(bamdata,Q_priors){

    bampriors = bam_priors(bamdata = bamdata, logQ_sd = Q_priors$logQ_sd, variant = "amhg",classification='expert')
    bampriors$other_priors$lowerbound_logQ = Q_priors$lowerbound_logQ
    bampriors$other_priors$upperbound_logQ = Q_priors$upperbound_logQ
    bampriors$other_priors$logQ_hat=rep(Q_priors$logQ_hat, times=ncol(Wobs))
    bampriors$other_priors$logQ_sd=rep(Q_priors$logQ_sd, times=ncol(Wobs))
    return(bampriors)
  }
  

    #create other BAM priors (can be adjusted)
    bampriors = makeBamPriors(bamdata,Q_priors)

    
    #print(bampriors$other_priors)
    norm_to_lognorm=function(mu,sigma){
    lognorm_mu=2*log(mu)-0.5*log(mu^2+sigma^2)
    lognorm_sigma= log(mu^2 + sigma^2) - 2*(log(mu))
    return(list('mu'=lognorm_mu,'sigma'=lognorm_sigma))}


#nudge priors
bampriors$logWb_hat = rep(log(max(bamdata$Wobs[bamdata$Wobs>0])),times=nrow(bamdata$Wobs))
bampriors$river_type_priors$lowerbound_logDb=log(1.001)
bampriors$river_type_priors$logDb_hat[bampriors$river_type_priors$logDb_hat<bampriors$river_type_priors$lowerbound_logDb]= bampriors$river_type_priors$lowerbound_logDb +0.1
                       
return(list('geo_priors'=bampriors,
            'date'=date,
            'Wobs'=Wobs,
            'Sobs'=Sobs,
            'Q_priors'=Q_priors))
    
}