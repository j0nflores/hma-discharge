generate_neobam_priors_and_data = function(data_object, params) {
 
 
  logQ_hat= data_object$Q_priors$logQ_hat 
  lowerbound_logQ= data_object$Q_priors$lowerbound_logQ
  upperbound_logQ=data_object$Q_priors$upperbound_logQ
  logQ_sd= data_object$Q_priors$logQ_sd

  #performative variables
  nx=nrow(data_object$Wobs)
  nt=ncol(data_object$Wobs)
  ntot=data_object$ntot
  hasdat=data_object$hasdat
  Wobs=data_object$Wobs
  Sobs=data_object$Sobs
    
neobam_data_and_priors = list(

    Wobs=Wobs,
    Sobs=Sobs,
logQ_hat=logQ_hat,
lowerbound_logQ=lowerbound_logQ,
upperbound_logQ=upperbound_logQ,
logQ_sd=logQ_sd,
  
nx=nx,
nt=nt,
ntot=ntot,
hasdat=hasdat,
iter=params$iter,

Werr_sd=params$Werr_sd, #expected uncertainty in width observations
Serr_sd=params$Serr_sd, #expected uncerainty in slope observations
iter=params$iter, #how many iterations in the markov chain?
sigma_man=matrix(params$sigma_man,nrow=nrow(Wobs),ncol=ncol(Wobs)),
    
logWb_hat = params$logWb_hat,
logWb_sd =params$logWb_sd,
lowerbound_logWb = params$lowerbound_logWb,
upperbound_logWb = params$upperbound_logWb,

logDb_hat = params$logDb_hat,
logDb_sd = params$logDb_sd,
lowerbound_logDb = params$lowerbound_logDb,
upperbound_logDb = params$upperbound_logDb,
    
r_hat = params$r_hat,
r_sd = params$r_sd,
lowerbound_r = params$lowerbound_r,
upperbound_r = params$upperbound_r,

logn_hat = params$logn_hat,
logn_sd = params$logn_sd,
lowerbound_logn = params$lowerbound_logn,
upperbound_logn = params$upperbound_logn

  
  )
  
  
}

run_neobam = function(neobam_data_and_priors,sourcefile){
    
  #run it here

  library(BH,quietly=TRUE,warn.conflicts = FALSE)
  library(rstan,quietly=TRUE,warn.conflicts = FALSE)
  library(dplyr,quietly=TRUE,warn.conflicts = FALSE)
  library(tidyr, lib.loc = "/nas/cee-water/cjgleason/r-lib/",quietly=TRUE,warn.conflicts = FALSE)
  library(stringr,quietly=TRUE,warn.conflicts = FALSE)
    
    rstan_options(auto_write = TRUE)


    
  return_posterior_mean_sd= function(parameter,stan_output){
    
    
    var_names=gsub("\\[.*\\]" ,"",   row.names(stan_output) )
    parameter_index=!is.na(str_match(var_names,parameter))
    string_length_index=unlist(lapply(var_names,nchar)) == nchar(parameter)
    
    combined_index=which(parameter_index*string_length_index==1)
    
    posterior_mean=mean(stan_output[combined_index,]$mean)
    posterior_sd=sqrt(mean(stan_output[combined_index,]$sd^2))
    
    return(list('mean'=posterior_mean,'sd'=posterior_sd))
    
  }
    
    
return_Q_posterior=function(stan_output){
    parameter='logQ'

    var_names=gsub("\\[.*\\]" ,"",   row.names(stan_output) )
    parameter_index=!is.na(str_match(var_names,parameter))
    string_length_index=unlist(lapply(var_names,nchar)) == nchar(parameter)
    
    combined_index=which(parameter_index*string_length_index==1)
    posterior_Q=stan_output[combined_index,]$mean
    posterior_sd=stan_output[combined_index,]$sd
    
    return(list('logQ'=posterior_Q,'sd'=posterior_sd))
    
  }

  
    iter=neobam_data_and_priors$iter
    
        
  fit1 <- stan(
    
    file = sourcefile,  # Stan program
    data = neobam_data_and_priors,    # named list of data
    chains = 1,             # number of Markov chains
    warmup = floor(0.1*iter),          # number of warmup iterations per chain
    iter = iter,   # total number of iterations per chain
    cores = 1,              # number of cores (could use one per chain)
    refresh = 0
    #        boost_lib='/home/cjgleason_umass_edu/R/x86_64-pc-linux-gnu-library/4.0',
   #   eigen_lib='/home/cjgleason_umass_edu/R/x86_64-pc-linux-gnu-library/4.0'
  )
  
  
  
  output= data.frame(rstan::summary(fit1)$summary)
  #OK! we now need a list of all the posteriors so we can return them to stuff back into the flow law
  posterior_list=c('r','logn','logWb','logDb','logQ')
    
  posteriors=lapply(posterior_list,return_posterior_mean_sd,output)
  names(posteriors)=posterior_list
           
  logQ=return_Q_posterior(output)
  posteriors$logQ=logQ
    
  return(posteriors)

}

remake_discharge =function (Wobs,Sobs,posteriors){
  r=posteriors$r$mean
  logWb=posteriors$logWb$mean
  logDb=posteriors$logDb$mean
  logn=posteriors$logn$mean

delta=(1.67*r) +1
logQ=  (delta*log(Wobs))-(1.67*r*logWb)+(1.67*logDb)-(1.67*log((r+1)/r))-(logn)+(0.5*log(Sobs))

logQ[is.infinite(logQ)]=NA

Q=exp(colMeans(logQ,na.rm=T))

  
}


norm_to_lognorm=function(mu,sigma){
    lognorm_mu=2*log(mu)-0.5*log(mu^2+sigma^2)
    lognorm_sigma= log(mu^2 + sigma^2) - 2*(log(mu))
    return(list('mu'=lognorm_mu,'sigma'=lognorm_sigma))
    
}








