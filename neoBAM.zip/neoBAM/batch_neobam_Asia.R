batch_neobam_Asia=function(datafile,input_folder,output_folder){
    
options(warn =-1)

#libraries, paths, directories
source('/nas/cee-water/cjgleason/colin/Asia_neobam/neobam_functions_Asia.R')
source('/nas/cee-water/cjgleason/colin/Asia_neobam/generate_priors.R')
source('/nas/cee-water/cjgleason/colin/Asia_neobam/run_neobam_Asia.R')
source('/nas/cee-water/cjgleason/colin/Asia_neobam/prior_functions.R')
library(ncdf4,  lib.loc = "/nas/cee-water/cjgleason/r-lib/",quietly=TRUE,warn.conflicts=FALSE)
library(dplyr,warn.conflicts=FALSE,quietly=TRUE)
library(tidyr, lib.loc = "/nas/cee-water/cjgleason/r-lib/",warn.conflicts=FALSE,quietly=TRUE)
library(hydroGOF, lib.loc = "/nas/cee-water/cjgleason/r-lib/",warn.conflicts=FALSE,quietly=TRUE)
library(ggplot2, lib.loc = "/nas/cee-water/cjgleason/r-lib/",warn.conflicts=FALSE,quietly=TRUE)

#read in data------------------------------------
setwd(input_folder)
data_in = readRDS(datafile)
    
 
    
Qmean = data_in$q_mean
Qstd = data_in$q_sd
Qmin = data_in$q_min
Qmax = data_in$q_max


Q_priors=list() #need Qhat, Qsd, and bounds from GRADES
Q_priors$logQ_hat=log(Qmean)
Q_priors$lowerbound_logQ=min(log(Qmin))
Q_priors$upperbound_logQ=max(log(Qmax))
Q_priors$logQ_sd=norm_to_lognorm(Qmean,Qstd)$sigma
    
 

   
Wobs=data_in$widthdata %>%
    distinct()%>%
    mutate(comboid=paste0(date,ID))%>% #sometimes there are more than one width per xs on a given day, which throws off the pivot_wider. Handle this by dropping rows with duplicate ID/date pairs.
    distinct(comboid, .keep_all=TRUE)%>%
    select(-comboid)%>%
    pivot_wider(names_from=c(date), values_from = width) %>% #tidy data frame to matrix
    select(-ID,-COMID)%>%
    as.matrix() 

  Wobs[Wobs>100000] = NA #quality control
  Wobs[is.na(Wobs)] = NA #for Stan
    
#print(Wobs)
   
Sobs = data_in$slope#bed slope. Single value we will matricize later
date=colnames(Wobs)
  
    reachid=data_in$widthdata$COMID[1] 
    
    
 if(any(is.na(Q_priors)) || ncol(Wobs)<5 || nrow(Wobs)<5 || is.na(Sobs)){
          saveRDS(list('neobam_Q'=NA,
            'reachid'=NA,
            'neo_time'=NA),
        paste0(output_folder,reachid,'.rds'))
    return(NA)
  }
    

#------------------------------------------------------------
    
#run geobam 
geobam_parameters=list(
Wobs=Wobs,
Sobs=Sobs,
Q_priors=Q_priors,
date=date,
sample_size=15)

#this function does data prep and generate priors
geobam_outputs= generate_priors(geobam_parameters)
    
    #cleaned stuff up, need to redeclare
Wobs=geobam_outputs$Wobs
Sobs=geobam_outputs$Sobs
Q_priors=geobam_outputs$Q_priors
date=geobam_outputs$date

if (is.na(geobam_outputs$geo_priors)){
    saveRDS(list('neobam_Q'=NA,
            'reachid'=NA,
            'neo_time'=NA),
        paste0(output_folder,reachid,'.rds'))
    return(NA)
}
    
    
#run neobam
neobam_parameters=list(
    Wobs=Wobs,
    Sobs=Sobs,
    date=date,
    perc_lower=  0.1, #outliers
    perc_upper=  0.9, 
    nt_window=  ncol(Wobs),
    Werr_sd=    120,
    Serr_sd=    0.001,
    iter=       1500,
    logWb_hat=      geobam_outputs$geo_priors$river_type_priors$logWb_hat,
    logWb_sd=    geobam_outputs$geo_priors$river_type_priors$logWb_sd,
    lowerbound_logWb=    geobam_outputs$geo_priors$river_type_priors$lowerbound_logWb,
    upperbound_logWb=       geobam_outputs$geo_priors$river_type_priors$upperbound_logWb,    
    logDb_hat=      geobam_outputs$geo_priors$river_type_priors$logDb_hat,
    logDb_sd=    geobam_outputs$geo_priors$river_type_priors$logDb_sd,
    lowerbound_logDb=       geobam_outputs$geo_priors$river_type_priors$lowerbound_logDb,
    upperbound_logDb=       geobam_outputs$geo_priors$river_type_priors$upperbound_logDb,
    r_hat=       exp(geobam_outputs$geo_priors$river_type_priors$logr_hat),
    r_sd=     exp(geobam_outputs$geo_priors$river_type_priors$logr_sd),
    lowerbound_r=        exp(geobam_outputs$geo_priors$river_type_priors$lowerbound_logr),
    upperbound_r=        exp(geobam_outputs$geo_priors$river_type_priors$upperbound_logr),
    logn_hat=       geobam_outputs$geo_priors$river_type_priors$logn_hat,
    logn_sd=     geobam_outputs$geo_priors$river_type_priors$logn_sd,
    lowerbound_logn=        geobam_outputs$geo_priors$river_type_priors$lowerbound_logn,
    upperbound_logn=        geobam_outputs$geo_priors$river_type_priors$upperbound_logn,
    sigma_man=  geobam_outputs$geo_priors$other_priors$sigma_man[1,1],
    reachid=reachid,
    Q_priors=Q_priors


)
    
    #print(neobam_parameters$Q_priors)

#run neobam
neo_start=Sys.time()
neobam_outputs=run_neobam_Asia(neobam_parameters)
neo_time=Sys.time()-neo_start

saveRDS(list('neobam_Q'=neobam_outputs,
            'reachid'=reachid,
            'neo_time'=neo_time),
        paste0(output_folder,reachid,'.rds'))
    
    return(list('neobam_Q'=neobam_outputs,
            'reachid'=reachid,
            'neo_time'=neo_time))

}
