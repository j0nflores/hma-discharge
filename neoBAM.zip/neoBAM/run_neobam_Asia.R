run_neobam_Asia=function(parameters){

#libraries, paths, directories
source('/nas/cee-water/cjgleason/colin/Asia_neobam/neobam_functions_Asia.R')
library(ncdf4, lib.loc = "/nas/cee-water/cjgleason/r-lib/",quietly=TRUE,warn.conflicts=FALSE)
library(dplyr,warn.conflicts=FALSE,quietly=TRUE)
library(hydroGOF, lib.loc = "/nas/cee-water/cjgleason/r-lib/",warn.conflicts=FALSE,quietly=TRUE)
library(ggplot2, lib.loc = "/nas/cee-water/cjgleason/r-lib/",warn.conflicts=FALSE,quietly=TRUE)


Wobs=parameters$Wobs
Sobs=parameters$Sobs
date=parameters$date
Q_priors=parameters$Q_priors
    reachid=parameters$reachid
    
Wobs[is.na(Wobs)] = 0
        
hasdat=matrix(as.integer(Wobs>0),nrow=nrow(Wobs),ncol=ncol(Wobs))
ntot=sum(hasdat)
    

    
data_object=list('Wobs'=Wobs,
                'Sobs'=Sobs,
                'ntot'=ntot,
                'hasdat'=hasdat,
                'nx'=nrow(Wobs),
                'nt'=ncol(Wobs),
                 'Q_priors'=Q_priors
                )    
    
    #print(parameters)

# generate priors and data 
neobam_data_and_priors=generate_neobam_priors_and_data(data_object,parameters)
#output neobam_data_and_priors
    #this output is a list of all the data and priors needed to run neobam in a single object

# run on the window
sourcefile = '/nas/cee-water/cjgleason/colin/neobam_future/neobam/neobam_stan_engine.stan' #path to the stan engine for neobam
#sourcefile= '/nas/cee-water/cjgleason/colin/Verify/neobam/neobam/neobam_stan_engine.stan'
    
hydrograph=matrix(nrow=3,ncol=ncol(Wobs))
    sd=hydrograph

for (i in 1:3){
posteriors = run_neobam(neobam_data_and_priors,sourcefile)
  #  print(posteriors)
hydrograph[i,]= exp(posteriors$logQ$logQ)
sd[i,]=exp(posteriors$logQ$sd)
    }

final_hydrograph=colMeans(hydrograph)
uncertainty=colMeans(sd)
    
   # print(final_hydrograph)

neobam_Q=data.frame(neobam=final_hydrograph,date=date,COMID=reachid,sd=uncertainty)%>%
    unique
  
    return(list('neobam_Q'=neobam_Q))
}


